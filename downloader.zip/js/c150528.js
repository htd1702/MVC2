/*
$(function(){
	
// ã¾ãã¯Isotopeãå®è¡ãã¾ãã
var $container = $('.grid').isotope();

// jQueryãä½¿ã£ã¦ãã¯ãªãã¯ã¤ãã³ããè¿½å 
$('.filters, .sort1').on( 'click', 'label', function() {
  //ã¯ãªãã¯ãããã¿ã³ã®data-filterã®å¤ãå¤æ°ã«æ ¼ç´ãã¾ã
  var filterValue = $(this).attr('data-filter');
  //ããã§ãªãã·ã§ã³ã®filterãçºåããã¦ãã¾ãã
  //date-filterã®å¤ãä½¿ã£ã¦ãã£ã«ã¿ãªã³ã°ãè¡ãã¾ãã
  $container.isotope({ filter: filterValue });
});

});
*/
