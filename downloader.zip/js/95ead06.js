$(function(){
	
$('.nav_open').click(function() {
	var listId = $(this).parent().attr('id');
    $('.hideNav div.'+listId).animate({
        width: 'toggle'
    }, 300).siblings().hide(300);
	$(this).parent().toggleClass('active').siblings("li").removeClass('active');
});

});