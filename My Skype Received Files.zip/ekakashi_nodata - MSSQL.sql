USE MASTER

GO

CREATE DATABASE ekakashi

GO

USE ekakashi

--
-- MSSQL Script for ekakashi project
--

--
-- Name: admin; Type: TABLE
--

CREATE TABLE admin (
    id int identity (1,1) primary key,
    user_name nvarchar(255) NOT NULL,
    password nvarchar(255) NOT NULL,
    salt nvarchar(40),
    admin_class int NOT NULL,
    last_name nvarchar(50) NOT NULL,
    first_name nvarchar(50) NOT NULL,
    email nvarchar(255) NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: api_access; Type: TABLE;
--

CREATE TABLE api_access (
    id int identity(1, 1) primary key,
    client_id int NOT NULL,
    access_date datetime NOT NULL,
    access_count int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL
);

--
-- Name: chart; Type: TABLE;
--

CREATE TABLE chart (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    x_axis_sensor_mesure_item_id int,
    name nvarchar(255) NOT NULL,
    width int NOT NULL,
    height int NOT NULL,
    term_type int NOT NULL,
    term_class int,
    term int,
    start_date datetime DEFAULT NULL,
    end_date datetime DEFAULT NULL,
    sort_no int NOT NULL,
    is_x_axis_datetime bit NOT NULL,
    x_axis_unit int NOT NULL,
    x_axis_aggregate_type int,
    is_x_axis_integration bit,
    is_x_axis_moving_average bit,
    x_axis_moving_average_num int,
    x_axis_basis_value decimal(5,1) DEFAULT 0,
    display_flag bit DEFAULT 1,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: chart_sn_config; Type: TABLE;
--

CREATE TABLE chart_sn_config (
    chart_id int NOT NULL,
    sn_config_id int NOT NULL
);

--
-- Name: chart_y_axis; Type: TABLE;
--

CREATE TABLE chart_y_axis (
    id int identity(1, 1) primary key,
    chart_id int,
    axis_side int NOT NULL,
    axis_type int NOT NULL,
    aggregate_type int NOT NULL,
    is_integration bit,
    graph_type int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: chart_y_axis_sensor_measure_item; Type: TABLE;
--

CREATE TABLE chart_y_axis_sensor_measure_item (
    chart_y_axis_id int NOT NULL,
    sensor_measure_item_id int NOT NULL
);

--
-- Name: client; Type: TABLE;
--

CREATE TABLE client (
    id int identity(1, 1) primary key,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    client_name nvarchar(255) NOT NULL,
    client_name_kana nvarchar(255) DEFAULT NULL,
    capital bigint,
    url nvarchar(255) DEFAULT NULL,
    rep_branch nvarchar(255) DEFAULT NULL,
    rep_post nvarchar(255) DEFAULT NULL,
    rep_name nvarchar(255) DEFAULT NULL,
    rep_kana nvarchar(255) DEFAULT NULL,
    pic_branch nvarchar(255) DEFAULT NULL,
    pic_post nvarchar(255) DEFAULT NULL,
    pic_name nvarchar(255) NOT NULL,
    pic_kana nvarchar(255) DEFAULT NULL,
    address_zip nvarchar(10) NOT NULL,
    address_pref nvarchar(50) NOT NULL,
    address_city nvarchar(255) NOT NULL,
    address_block nvarchar(255) NOT NULL,
    address_bldg nvarchar(255) DEFAULT NULL,
    phone nvarchar(15) NOT NULL,
    mobile nvarchar(15) DEFAULT NULL,
    fax nvarchar(15) DEFAULT NULL,
    email nvarchar(255) NOT NULL,
    payment_terms nvarchar(255) DEFAULT NULL,
    document_delivery int NOT NULL,
    document_method int,
    product_delivery int NOT NULL,
    document_delivery_branch nvarchar(255) DEFAULT NULL,
    document_delivery_post nvarchar(255) DEFAULT NULL,
    document_delivery_pic_name nvarchar(255) DEFAULT NULL,
    document_delivery_pic_kana nvarchar(255) DEFAULT NULL,
    document_delivery_address_zip nvarchar(10) DEFAULT NULL,
    document_delivery_address_pref nvarchar(50) DEFAULT NULL,
    document_delivery_address_city nvarchar(255) DEFAULT NULL,
    document_delivery_address_block nvarchar(255) DEFAULT NULL,
    document_delivery_address_bldg nvarchar(255) DEFAULT NULL,
    document_delivery_phone nvarchar(15) DEFAULT NULL,
    document_delivery_mobile nvarchar(15) DEFAULT NULL,
    document_delivery_fax nvarchar(15) DEFAULT NULL,
    document_delivery_email nvarchar(255) DEFAULT NULL,
    product_delivery_branch nvarchar(255) DEFAULT NULL,
    product_delivery_post nvarchar(255) DEFAULT NULL,
    product_delivery_pic_name nvarchar(255) DEFAULT NULL,
    product_delivery_pic_kana nvarchar(255) DEFAULT NULL,
    product_delivery_address_zip nvarchar(10) DEFAULT NULL,
    product_delivery_address_pref nvarchar(50) DEFAULT NULL,
    product_delivery_address_city nvarchar(255) DEFAULT NULL,
    product_delivery_address_block nvarchar(255) DEFAULT NULL,
    product_delivery_address_bldg nvarchar(255) DEFAULT NULL,
    produce_delivery_phone nvarchar(15) DEFAULT NULL,
    product_delivery_mobile nvarchar(15) DEFAULT NULL,
    product_delivery_fax nvarchar(15) DEFAULT NULL,
    product_delivery_email nvarchar(255) DEFAULT NULL
);

--
-- Name: client_ek_user; Type: TABLE;
--

CREATE TABLE client_ek_user (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    ek_user_id int,
    auth_class int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: client_ekuser_sn_config; Type: TABLE;
--

CREATE TABLE client_ekuser_sn_config (
    client_ek_user_id int NOT NULL,
    sn_config_id int NOT NULL
);

--
-- Name: client_system_info; Type: TABLE;
--

CREATE TABLE client_system_info (
    id int identity(1, 1) primary key,
    client_id int,
    is_available_web bit NOT NULL,
    is_available_api bit NOT NULL,
    initial_ek_user_id int,
    initial_ek_user_name nvarchar(255) DEFAULT NULL,
    initial_ek_user_password nvarchar(255) DEFAULT NULL,
    api_id nvarchar(255) DEFAULT NULL,
    api_password nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: contract; Type: TABLE;
--

CREATE TABLE contract (
    id int identity(1, 1) primary key,
    client_id int,
    contract_date datetime DEFAULT NULL,
    delivery_date datetime DEFAULT NULL,
    use_start_date datetime DEFAULT NULL,
    use_end_date datetime DEFAULT NULL,
    contract_web int,
    contract_api int,
    shipping_status int,
    shipping_status_update_datetime datetime DEFAULT NULL,
    gw_quantity int NOT NULL,
    sn_quantity int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    client_name nvarchar(255) NOT NULL,
    client_name_kana nvarchar(255) DEFAULT NULL,
    capital bigint,
    url nvarchar(255) DEFAULT NULL,
    rep_branch nvarchar(255) DEFAULT NULL,
    rep_post nvarchar(255) DEFAULT NULL,
    rep_name nvarchar(255) DEFAULT NULL,
    rep_kana nvarchar(255) DEFAULT NULL,
    pic_branch nvarchar(255) DEFAULT NULL,
    pic_post nvarchar(255) DEFAULT NULL,
    pic_name nvarchar(255) NOT NULL,
    pic_kana nvarchar(255) DEFAULT NULL,
    address_zip nvarchar(10) NOT NULL,
    address_pref nvarchar(50) NOT NULL,
    address_city nvarchar(255) NOT NULL,
    address_block nvarchar(255) NOT NULL,
    address_bldg nvarchar(255) DEFAULT NULL,
    phone nvarchar(15) NOT NULL,
    mobile nvarchar(15) DEFAULT NULL,
    fax nvarchar(15) DEFAULT NULL,
    email nvarchar(255) NOT NULL,
    payment_terms nvarchar(255) DEFAULT NULL,
    document_delivery int NOT NULL,
    document_method int,
    product_delivery int NOT NULL,
    document_delivery_branch nvarchar(255) DEFAULT NULL,
    document_delivery_post nvarchar(255) DEFAULT NULL,
    document_delivery_pic_name nvarchar(255) DEFAULT NULL,
    document_delivery_pic_kana nvarchar(255) DEFAULT NULL,
    document_delivery_address_zip nvarchar(10) DEFAULT NULL,
    document_delivery_address_pref nvarchar(50) DEFAULT NULL,
    document_delivery_address_city nvarchar(255) DEFAULT NULL,
    document_delivery_address_block nvarchar(255) DEFAULT NULL,
    document_delivery_address_bldg nvarchar(255) DEFAULT NULL,
    document_delivery_phone nvarchar(15) DEFAULT NULL,
    document_delivery_mobile nvarchar(15) DEFAULT NULL,
    document_delivery_fax nvarchar(15) DEFAULT NULL,
    document_delivery_email nvarchar(255) DEFAULT NULL,
    product_delivery_branch nvarchar(255) DEFAULT NULL,
    product_delivery_post nvarchar(255) DEFAULT NULL,
    product_delivery_pic_name nvarchar(255) DEFAULT NULL,
    product_delivery_pic_kana nvarchar(255) DEFAULT NULL,
    product_delivery_address_zip nvarchar(10) DEFAULT NULL,
    product_delivery_address_pref nvarchar(50) DEFAULT NULL,
    product_delivery_address_city nvarchar(255) DEFAULT NULL,
    product_delivery_address_block nvarchar(255) DEFAULT NULL,
    product_delivery_address_bldg nvarchar(255) DEFAULT NULL,
    produce_delivery_phone nvarchar(15) DEFAULT NULL,
    product_delivery_mobile nvarchar(15) DEFAULT NULL,
    product_delivery_fax nvarchar(15) DEFAULT NULL,
    product_delivery_email nvarchar(255) DEFAULT NULL
);

--
-- Name: contract_gw; Type: TABLE;
--

CREATE TABLE contract_gw (
    contract_id int identity(1, 1) primary key,
    gw_id nvarchar(12) NOT NULL
);

--
-- Name: contract_sensor; Type: TABLE;
--

CREATE TABLE contract_sensor (
    id int identity(1, 1) primary key,
    contract_id int,
    sensor_id int,
    quantity int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    sensor_model int
);

--
-- Name: contract_sn; Type: TABLE;
--

CREATE TABLE contract_sn (
    contract_id int identity(1, 1) primary key,
    sn_id nvarchar(12) NOT NULL
);

--
-- Name: diary; Type: TABLE; Schema: public; Owner: ews; Tablespace: 
--

CREATE TABLE diary (
    id int identity(1, 1) primary key,
    issued_datetime datetime NOT NULL,
    client_id int,
    ek_user_id int NOT NULL,
    title nvarchar(255) NOT NULL,
    content text,
    image_path nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: diary_ek_field; Type: TABLE;
--

CREATE TABLE diary_ek_field (
    diary_id int NOT NULL,
    ek_field_id int NOT NULL
);

--
-- Name: diary_sn_config; Type: TABLE;
--

CREATE TABLE diary_sn_config (
    diary_id int NOT NULL,
    sn_config_id int NOT NULL
);

--
-- Name: ek_user; Type: TABLE;
--

CREATE TABLE ek_user (
    id int identity(1, 1) primary key,
    user_name nvarchar(255) NOT NULL,
    password nvarchar(255) NOT NULL,
    salt nvarchar(40) DEFAULT NULL,
    official_user_flag int NOT NULL,
    name nvarchar(50) DEFAULT NULL,
    nick_name nvarchar(50) DEFAULT NULL,
    email nvarchar(255) DEFAULT NULL,
    valid_email bit DEFAULT 0,
    last_login_datetime datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    is_active bit DEFAULT 0
);

--
-- Name: ek_user_config; Type: TABLE;
--

CREATE TABLE ek_user_config (
    id int identity(1, 1) primary key,
    ek_user_id int,
    locale nvarchar(32) DEFAULT NULL,
    timezone nvarchar(32) DEFAULT NULL,
    mail_charset nvarchar(32) DEFAULT NULL,
    default_page nvarchar(255) DEFAULT NULL,
    selected_client_id int NOT NULL,
    notice_open_datetime datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    send_alart_mail_flag smallint
);


-- Name: ek_user_config_gw_config; Type: TABLE;
--

CREATE TABLE ek_user_config_gw_config (
    ek_user_config_id int NOT NULL,
    gw_config_id int NOT NULL,
    enable_suspending_alert smallint NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL
);

--
-- Name: ek_user_config_sn_config; Type: TABLE;
--

CREATE TABLE ek_user_config_sn_config (
    ek_user_config_id int NOT NULL,
    sn_config_id int NOT NULL,
    enable_suspending_alert smallint,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    enable_threshold_alert smallint
);

--
-- Name: ekfield; Type: TABLE;
--

CREATE TABLE ekfield (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    recipe_id int,
    recipe_stage_id int,
    name nvarchar(255) NOT NULL,
    color nvarchar(10) DEFAULT NULL,
    summary text,
    cultivated_crop nvarchar(255) NOT NULL,
    start_date datetime NOT NULL,
    end_date datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    sent_start_mail bit,
    ek_user_id int,
    contest_flag smallint DEFAULT 0
);

--
-- Name: ekfield_chart; Type: TABLE;
--

CREATE TABLE ekfield_chart (
    chart_id int NOT NULL,
    ekfield_id int NOT NULL
);

--
-- Name: ekfield_graph; Type: TABLE;
--

CREATE TABLE ekfield_graph (
    graph_id int NOT NULL,
    ekfield_id int NOT NULL
);

--
-- Name: ekfield_graph_v2; Type: TABLE;
--

CREATE TABLE ekfield_graph_v2 (
    graph_y_axis_id int NOT NULL,
    ekfield_id int NOT NULL
);

--
-- Name: ekfield_recipe_stage_history; Type: TABLE;
--

CREATE TABLE ekfield_recipe_stage_history (
    id int identity(1, 1) primary key,
    ekfield_id int,
    recipe_stage_id int,
    stage_start_datetime datetime DEFAULT NULL,
    stage_end_datetime datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: ekfield_recipe_stage_widget_config; Type: TABLE;
--

CREATE TABLE ekfield_recipe_stage_widget_config (
    id int identity(1, 1) primary key,
    ek_field_recipe_stage_history_id int,
    stage_widget_id int,
    sn_config_id int,
    start_datetime datetime DEFAULT NULL,
    end_datetime datetime DEFAULT NULL,
    basis_value decimal(5,1) DEFAULT 0,
    goal_value double precision,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: ekfield_sensor_measure_item; Type: TABLE;
--

CREATE TABLE ekfield_sensor_measure_item (
    id int identity(1, 1) primary key,
    ekfield_id int,
    recipe_stage_id int,
    sensor_measure_item_id int,
    item_name nvarchar(255) NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: ekfield_sensor_position; Type: TABLE;
--

CREATE TABLE ekfield_sensor_position (
    id int identity(1, 1) primary key,
    ekfield_id int,
    sensor_type smallint NOT NULL,
    title nvarchar(255) DEFAULT NULL,
    url text,
    description text,
    image_path nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    recipe_stage_id int
);

--
-- Name: ekfield_sn_config; Type: TABLE;
--

CREATE TABLE ekfield_sn_config (
    ekfield_id int NOT NULL,
    snconfig_id int NOT NULL
);

--
-- Name: ext_log_entries; Type: TABLE;
--

CREATE TABLE ext_log_entries (
    id int identity(1, 1) primary key,
    action nvarchar(8) NOT NULL,
    logged_at datetime NOT NULL,
    object_id nvarchar(64) DEFAULT NULL,
    object_class nvarchar(255) NOT NULL,
    version int NOT NULL,
    data text,
    username nvarchar(255) DEFAULT NULL
);

--
-- Name: ext_translations; Type: TABLE;
--

CREATE TABLE ext_translations (
    id int identity(1, 1) primary key,
    locale nvarchar(8) NOT NULL,
    object_class nvarchar(255) NOT NULL,
    field nvarchar(32) NOT NULL,
    foreign_key nvarchar(64) NOT NULL,
    content text
);

--
-- Name: ext_translations_sector; Type: TABLE;
--

CREATE TABLE ext_translations_sector (
    id int identity(1, 1) primary key,
    locale nvarchar(8) NOT NULL,
    object_class nvarchar(255) NOT NULL,
    field nvarchar(32) NOT NULL,
    foreign_key nvarchar(64) NOT NULL,
    content text
);

--
-- Name: gearman_queue; Type: TABLE;
--

CREATE TABLE gearman_queue (
    unique_key nvarchar(64),
    function_name nvarchar(255),
    priority int,
    data binary,
    when_to_run int
);

--
-- Name: graph; Type: TABLE;
--

CREATE TABLE graph (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    x_axis_sensor_mesure_item_id int,
    name nvarchar(255) NOT NULL,
    width int NOT NULL,
    height int NOT NULL,
    term_type int NOT NULL,
    term_class int,
    term int,
    start_date datetime DEFAULT NULL,
    end_date datetime DEFAULT NULL,
    sort_no int NOT NULL,
    is_x_axis_datetime bit NOT NULL,
    x_axis_unit int NOT NULL,
    is_x_axis_moving_average bit,
    x_axis_moving_average_days int,
    x_axis_basis_value decimal(5,1) DEFAULT 0,
    display_flag bit DEFAULT 1 NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: graph_sn_config; Type: TABLE;
--

CREATE TABLE graph_sn_config (
    graph_id int NOT NULL,
    sn_config_id int NOT NULL
);

--
-- Name: graph_v2; Type: TABLE;
--

CREATE TABLE graph_v2 (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    x_axis_sensor_mesure_item_id int,
    name nvarchar(255) NOT NULL,
    width int NOT NULL,
    height int NOT NULL,
    term_type int NOT NULL,
    term_class int,
    term int,
    start_date datetime DEFAULT NULL,
    end_date datetime DEFAULT NULL,
    sort_no int NOT NULL,
    is_x_axis_datetime bit NOT NULL,
    x_axis_unit int NOT NULL,
    x_axis_aggregate_type int,
    is_x_axis_integration bit,
    is_x_axis_moving_average bit,
    x_axis_moving_average_num int,
    x_axis_basis_value decimal(5,1) DEFAULT 0,
    y_axis_left_type int NOT NULL,
    y_axis_right_type int NOT NULL,
    display_flag bit DEFAULT 1 NOT NULL,
    before_correction_flag bit DEFAULT 0 NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    ekfield_id int
);

--
-- Name: graph_v2_sn_config; Type: TABLE;
--

CREATE TABLE graph_v2_sn_config (
    graph_y_axis_id int NOT NULL,
    sn_config_id int NOT NULL
);

--
-- Name: graph_v2_y_axis; Type: TABLE;
--

CREATE TABLE graph_v2_y_axis (
    id int identity(1, 1) primary key,
    graph_id int,
    axis_side int NOT NULL,
    aggregate_type int NOT NULL,
    is_integration bit,
    graph_type int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    basis_value decimal(5,1) DEFAULT 0
);

--
-- Name: graph_v2_y_axis_sensor_measure_item; Type: TABLE
--

CREATE TABLE graph_v2_y_axis_sensor_measure_item (
    graph_y_axis_id int NOT NULL,
    sensor_measure_item_id int NOT NULL
);

--
-- Name: graph_y_axis; Type: TABLE;
--

CREATE TABLE graph_y_axis (
    id int identity(1, 1) primary key,
    graph_id int,
    axis_type int NOT NULL,
    unit int NOT NULL,
    graph_type int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: graph_y_axis_sensor_measure_item; Type: TABLE;
--

CREATE TABLE graph_y_axis_sensor_measure_item (
    graph_y_axis_id int NOT NULL,
    sensor_measure_item_id int NOT NULL
);

--
-- Name: gw; Type: TABLE;
--

CREATE TABLE gw (
    id nvarchar(12) NOT NULL,
    deleted_at datetime DEFAULT NULL,
    receiving_status_update_datetime datetime DEFAULT NULL,
    gw_name nvarchar(32) DEFAULT NULL,
    customer_name nvarchar(32) DEFAULT NULL,
    gw_device_type_id nvarchar(8) DEFAULT NULL,
    gw_device_type_name nvarchar(32) DEFAULT NULL,
    gps_information nvarchar(1500) DEFAULT NULL,
    latitude double precision,
    longitude double precision,
    icc_id nvarchar(19) DEFAULT NULL,
    ipv4_address nvarchar(15) DEFAULT NULL,
    radio_scan_mode binary,
    channel_id binary,
    connect_info_send_interval int,
    measure_data_send_interval int,
    item1 nvarchar(32) DEFAULT NULL,
    item2 nvarchar(32) DEFAULT NULL,
    item3 nvarchar(32) DEFAULT NULL,
    sn_white_list_file_data text,
    activation_status int,
    activation_status_update_datetime datetime DEFAULT NULL,
    control_status int,
    control_status_update_datetime datetime DEFAULT NULL,
    entry_status int,
    entry_status_update_datetime datetime DEFAULT NULL,
    line_status int,
    line_status_update_datetime datetime DEFAULT NULL,
    receiving_status int,
    connecting_time int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    latitude_user double precision,
    longitude_user double precision,
    latitude_m2m double precision,
    longitude_m2m double precision,
    geodetic_use_status smallint DEFAULT 1 NOT NULL,
    node_timezone nvarchar(50) DEFAULT NULL
);

--
-- Name: gw_config; Type: TABLE;
--

CREATE TABLE gw_config (
    id int identity(1, 1) primary key,
    gw_id nvarchar(12) DEFAULT NULL,
    client_system_info_id int,
    node_name nvarchar(255) DEFAULT NULL,
    node_color nvarchar(10) DEFAULT NULL,
    enable_suspending_alert smallint NOT NULL,
    sort_no int NOT NULL,
    contract_id int,
    use_start_datetime datetime DEFAULT NULL,
    use_end_datetime datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: gw_history; Type: TABLE;
--

CREATE TABLE gw_history (
    id int identity(1, 1) primary key,
    deleted_at datetime DEFAULT NULL,
    gw_id nvarchar(12) NOT NULL,
    client_id int,
    receiving_status_update_datetime datetime DEFAULT NULL,
    gw_name nvarchar(32) DEFAULT NULL,
    customer_name nvarchar(32) DEFAULT NULL,
    gw_device_type_id nvarchar(8) DEFAULT NULL,
    gw_device_type_name nvarchar(32) DEFAULT NULL,
    gps_information nvarchar(1500) DEFAULT NULL,
    latitude double precision,
    longitude double precision,
    icc_id nvarchar(19) DEFAULT NULL,
    ipv4_address nvarchar(15) DEFAULT NULL,
    radio_scan_mode binary,
    channel_id binary,
    connect_info_send_interval int,
    measure_data_send_interval int,
    item1 nvarchar(32) DEFAULT NULL,
    item2 nvarchar(32) DEFAULT NULL,
    item3 nvarchar(32) DEFAULT NULL,
    sn_white_list_file_data text,
    activation_status int,
    activation_status_update_datetime datetime DEFAULT NULL,
    control_status int,
    control_status_update_datetime datetime DEFAULT NULL,
    entry_status int,
    entry_status_update_datetime datetime DEFAULT NULL,
    line_status int,
    line_status_update_datetime datetime DEFAULT NULL,
    receiving_status int,
    connecting_time int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    latitude_user double precision,
    longitude_user double precision,
    latitude_m2m double precision,
    longitude_m2m double precision,
    geodetic_use_status smallint DEFAULT 1 NOT NULL,
    node_timezone nvarchar(50) DEFAULT NULL
);

--
-- Name: inquiry; Type: TABLE;
--

CREATE TABLE inquiry (
    id int identity(1, 1) primary key,
    ek_user_id int,
    inquiry_type int NOT NULL,
    os_version nvarchar(255) DEFAULT NULL,
    browser_version nvarchar(255) DEFAULT NULL,
    detail text,
    image_path nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: invitation; Type: TABLE;
--

CREATE TABLE invitation (
    id int identity(1, 1) primary key,
    invite_ek_user_id int,
    client_id int NOT NULL,
    invite_datetime datetime NOT NULL,
    invite_auth_class int NOT NULL,
    comment text,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: invitation_sn_config; Type: TABLE;
--

CREATE TABLE invitation_sn_config (
    invitation_id int NOT NULL,
    sn_config_id int NOT NULL
);

--
-- Name: invitation_user; Type: TABLE;
--

CREATE TABLE invitation_user (
    id int identity(1, 1) primary key,
    invitation_id int,
    ek_user_id int,
    email nvarchar(255) NOT NULL,
    invitation_status int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: m2mts; Type: TABLE;
--

CREATE TABLE m2mts (
    id int identity(1, 1) primary key,
    user_id nvarchar(20) NOT NULL,
    password nvarchar(50) NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: m2mts_session; Type: TABLE;
--

CREATE TABLE m2mts_session (
    id int identity(1, 1) primary key,
    m2mts_id int,
    session_id nvarchar(128) DEFAULT NULL,
    issued_datetime datetime DEFAULT NULL
);

--
-- Name: measure; Type: TABLE; Schema: public; Owner: ews; Tablespace: 
--

CREATE TABLE measure (
    id int identity(1, 1) primary key,
    endian_id binary,
    gw_id nvarchar(12) DEFAULT NULL,
    gw_time datetime DEFAULT NULL,
    gw_rssi_2 int,
    sn_id nvarchar(12) DEFAULT NULL,
    sn_rssi_1 int,
    measure_datetime datetime DEFAULT NULL,
    measure_sequence bigint,
    sn_battery_voltage decimal(5,2) DEFAULT NULL,
    temperature decimal(5,2) DEFAULT NULL,
    corrected_temperature decimal(5,2) DEFAULT NULL,
    humidity decimal(5,2) DEFAULT NULL,
    corrected_humidity decimal(5,2) DEFAULT NULL,
    thermistor1 decimal(5,2) DEFAULT NULL,
    corrected_thermistor1 decimal(5,2) DEFAULT NULL,
    thermistor2 decimal(5,2) DEFAULT NULL,
    corrected_thermistor2 decimal(5,2) DEFAULT NULL,
    thermistor3 decimal(5,2) DEFAULT NULL,
    corrected_thermistor3 decimal(5,2) DEFAULT NULL,
    thermistor4 decimal(5,2) DEFAULT NULL,
    corrected_thermistor4 decimal(5,2) DEFAULT NULL,
    soil_vwc decimal(5,2) DEFAULT NULL,
    corrected_soil_vwc decimal(5,2) DEFAULT NULL,
    ec decimal(3,2) DEFAULT NULL,
    corrected_ec decimal(3,2) DEFAULT NULL,
    solar_irradiance decimal(6,2) DEFAULT NULL,
    corrected_solar_irradiance decimal(6,2) DEFAULT NULL,
    option_analog decimal(6,2) DEFAULT NULL,
    option_serial int,
    connection_status int,
    absolute_humidity decimal(15,5) DEFAULT NULL,
    corrected_absolute_humidity decimal(15,5) DEFAULT NULL,
    humidity_deficit decimal(15,5) DEFAULT NULL,
    corrected_humidity_deficit decimal(15,5) DEFAULT NULL,
    dew_point decimal(15,5) DEFAULT NULL,
    corrected_dew_point decimal(15,5) DEFAULT NULL,
    co2 decimal(15,5) DEFAULT NULL,
    corrected_co2 decimal(15,5) DEFAULT NULL,
    measure_interval int,
    latitude double precision,
    longitude double precision,
    sunrise datetime DEFAULT NULL,
    sunset datetime DEFAULT NULL,
    day_night int,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    expression_temperature nvarchar(255) DEFAULT NULL,
    expression_humidity nvarchar(255) DEFAULT NULL,
    expression_thermistor1 nvarchar(255) DEFAULT NULL,
    expression_thermistor2 nvarchar(255) DEFAULT NULL,
    expression_thermistor3 nvarchar(255) DEFAULT NULL,
    expression_thermistor4 nvarchar(255) DEFAULT NULL,
    expression_soil_vwc nvarchar(255) DEFAULT NULL,
    expression_ec nvarchar(255) DEFAULT NULL,
    expression_solar_irradiance nvarchar(255) DEFAULT NULL,
    expression_absolute_humidity nvarchar(255) DEFAULT NULL,
    expression_humidity_deficit nvarchar(255) DEFAULT NULL,
    expression_dew_point nvarchar(255) DEFAULT NULL,
    expression_co2 nvarchar(255) DEFAULT NULL
);

--
-- Name: measure_summary_hourly; Type: TABLE;
--

CREATE TABLE measure_summary_hourly (
    id int identity(1, 1) primary key,
    sn_id nvarchar(12) NOT NULL,
    measure_datetime datetime NOT NULL,
    data_count int NOT NULL,
    measure_interval int NOT NULL,
    temperature_count int NOT NULL,
    temperature decimal(10,2) DEFAULT NULL,
    humidity_count int NOT NULL,
    humidity decimal(10,2) DEFAULT NULL,
    thermistor1_count int NOT NULL,
    thermistor1 decimal(10,2) DEFAULT NULL,
    thermistor2_count int NOT NULL,
    thermistor2 decimal(10,2) DEFAULT NULL,
    thermistor3_count int NOT NULL,
    thermistor3 decimal(10,2) DEFAULT NULL,
    thermistor4_count int NOT NULL,
    thermistor4 decimal(10,2) DEFAULT NULL,
    soil_vwc_count int NOT NULL,
    soil_vwc decimal(10,2) DEFAULT NULL,
    ec_count int NOT NULL,
    ec decimal(10,2) DEFAULT NULL,
    solar_irradiance_count int NOT NULL,
    solar_irradiance decimal(15,2) DEFAULT NULL,
    absolute_humidity_count int NOT NULL,
    absolute_humidity decimal(15,5) DEFAULT NULL,
    humidity_deficit_count int NOT NULL,
    humidity_deficit decimal(15,5) DEFAULT NULL,
    dew_point_count int NOT NULL,
    dew_point decimal(15,5) DEFAULT NULL,
    co2_count int NOT NULL,
    co2 decimal(15,5) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    corrected_temperature decimal(10,2) DEFAULT NULL,
    corrected_humidity decimal(10,2) DEFAULT NULL,
    corrected_thermistor1 decimal(10,2) DEFAULT NULL,
    corrected_thermistor2 decimal(10,2) DEFAULT NULL,
    corrected_thermistor3 decimal(10,2) DEFAULT NULL,
    corrected_thermistor4 decimal(10,2) DEFAULT NULL,
    corrected_soil_vwc decimal(10,2) DEFAULT NULL,
    corrected_ec decimal(10,2) DEFAULT NULL,
    corrected_solar_irradiance decimal(15,2) DEFAULT NULL,
    corrected_absolute_humidity decimal(15,5) DEFAULT NULL,
    corrected_humidity_deficit decimal(15,5) DEFAULT NULL,
    corrected_dew_point decimal(15,5) DEFAULT NULL,
    corrected_co2 decimal(15,5) DEFAULT NULL
);

--
-- Name: notification; Type: TABLE;
--

CREATE TABLE notification (
    id int identity(1, 1) primary key,
    outline nvarchar(255) NOT NULL,
    detail text NOT NULL,
    start_date datetime NOT NULL,
    end_date datetime NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: option_antenna; Type: TABLE;
--

CREATE TABLE option_antenna (
    id int identity(1, 1) primary key,
    contract_id int NOT NULL,
    antenna int NOT NULL,
    quantity int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: recipe; Type: TABLE;
--

CREATE TABLE recipe (
    id int identity(1, 1) primary key,
    ek_user_id int,
    parent_recipe_id int,
    sector_id int NOT NULL,
    sector_icon_id int,
    recipe_name nvarchar(255) NOT NULL,
    prefectures smallint NOT NULL,
    organization_name nvarchar(255) NOT NULL,
    description text,
    official_flag smallint DEFAULT 0 NOT NULL,
    public_flag smallint DEFAULT 0 NOT NULL,
    public_content1 bit,
    public_content2 bit,
    public_content3 bit,
    public_content4 bit,
    image_type smallint NOT NULL,
    image_path nvarchar(255) DEFAULT NULL,
    created_flag smallint DEFAULT 0 NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    contest_flag smallint DEFAULT 0
);

--
-- Name: recipe_keyword; Type: TABLE;
--

CREATE TABLE recipe_keyword (
    id int identity(1, 1) primary key,
    recipe_id int NOT NULL,
    sort_no int,
    keyword nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: recipe_request; Type: TABLE;
--

CREATE TABLE recipe_request (
    id int identity(1, 1) primary key,
    recipe_id int NOT NULL,
    ek_user_id int,
    client_id int,
    message text,
    request_status smallint DEFAULT 0 NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: recipe_stage; Type: TABLE;
--

CREATE TABLE recipe_stage (
    id int identity(1, 1) primary key,
    recipe_id int NOT NULL,
    stage_name nvarchar(255) NOT NULL,
    sort_no int,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sector; Type: TABLE;
--

CREATE TABLE sector (
    id int identity(1, 1) primary key,
    sector_name nvarchar(100) NOT NULL,
    sort_no int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sector_icon; Type: TABLE;
--

CREATE TABLE sector_icon (
    id int identity(1, 1) primary key,
    sector_id int,
    default_flag int NOT NULL,
    icon_css nvarchar(50) NOT NULL,
    icon_color nvarchar(50) NOT NULL,
    sort_no int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sensor; Type: TABLE;
--

CREATE TABLE sensor (
    id int identity(1, 1) primary key,
    sensor_name nvarchar(50) DEFAULT NULL,
    maker_name nvarchar(50) DEFAULT NULL,
    model_name nvarchar(50) DEFAULT NULL,
    purpose nvarchar(50) DEFAULT NULL,
    sort_no int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sensor_measure_item; Type: TABLE;
--

CREATE TABLE sensor_measure_item (
    id int identity(1, 1) primary key,
    sensor_id int,
    item_name nvarchar(25) NOT NULL,
    unit nvarchar(10) DEFAULT NULL,
    sort_no int NOT NULL,
    icon_html text,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sn; Type: TABLE;
--

CREATE TABLE sn (
    id nvarchar(12) NOT NULL,
    deleted_at datetime DEFAULT NULL,
    sn_name nvarchar(32) DEFAULT NULL,
    sn_customer_name nvarchar(32) DEFAULT NULL,
    gps_information nvarchar(1500) DEFAULT NULL,
    latitude double precision,
    longitude double precision,
    sn_device_type_id nvarchar(8) DEFAULT NULL,
    sn_device_type_name nvarchar(32) DEFAULT NULL,
    measure_interval int,
    measure_start_time datetime DEFAULT NULL,
    item1 nvarchar(255) DEFAULT NULL,
    item2 nvarchar(32) DEFAULT NULL,
    item3 nvarchar(32) DEFAULT NULL,
    activation_status int,
    activation_status_update_datetime datetime DEFAULT NULL,
    control_status int,
    control_status_udpate_datetime datetime DEFAULT NULL,
    entry_status int,
    entry_status_update_datetime datetime DEFAULT NULL,
    measure_data_last_datetime datetime DEFAULT NULL,
    receiving_status int,
    receiving_status_update_datetime datetime DEFAULT NULL,
    battery_voltage int,
    rssi1 int,
    rssi2 int,
    gw_id nvarchar(12) DEFAULT NULL,
    gw_name nvarchar(32) DEFAULT NULL,
    gw_customer_name nvarchar(32) DEFAULT NULL,
    gw_device_type_id nvarchar(8),
    icc_id nvarchar(19) DEFAULT NULL,
    ipv4_address nvarchar(15),
    sunrise datetime DEFAULT NULL,
    sunset datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    latitude_user double precision,
    longitude_user double precision,
    latitude_m2m double precision,
    longitude_m2m double precision,
    geodetic_use_status smallint DEFAULT 1 NOT NULL,
    node_timezone nvarchar(50) DEFAULT NULL
);

--
-- Name: sn_config; Type: TABLE;
--

CREATE TABLE sn_config (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    threshold_id int,
    node_name nvarchar(255) DEFAULT NULL,
    node_color nvarchar(10) DEFAULT NULL,
    enable_suspending_alert smallint NOT NULL,
    sort_no int NOT NULL,
    use_start_datetime datetime DEFAULT NULL,
    use_end_datetime datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sn_history; Type: TABLE;
--

CREATE TABLE sn_history (
    id int identity(1, 1) primary key,
    deleted_at datetime DEFAULT NULL,
    sn_id nvarchar(12) NOT NULL,
    client_id int,
    sn_name nvarchar(32) DEFAULT NULL,
    sn_customer_name nvarchar(32) DEFAULT NULL,
    gps_information nvarchar(1500) DEFAULT NULL,
    latitude double precision,
    longitude double precision,
    sn_device_type_id nvarchar(8) DEFAULT NULL,
    sn_device_type_name nvarchar(32) DEFAULT NULL,
    measure_interval int,
    measure_start_time datetime DEFAULT NULL,
    item1 nvarchar(255) DEFAULT NULL,
    item2 nvarchar(32) DEFAULT NULL,
    item3 nvarchar(32) DEFAULT NULL,
    activation_status int,
    activation_status_update_datetime datetime DEFAULT NULL,
    control_status int,
    control_status_udpate_datetime datetime DEFAULT NULL,
    entry_status int,
    entry_status_update_datetime datetime DEFAULT NULL,
    measure_data_last_datetime datetime DEFAULT NULL,
    receiving_status int,
    receiving_status_update_datetime datetime DEFAULT NULL,
    battery_voltage int,
    rssi1 int,
    rssi2 int,
    gw_id nvarchar(12) DEFAULT NULL,
    gw_name nvarchar(32) DEFAULT NULL,
    gw_customer_name nvarchar(32) DEFAULT NULL,
    gw_device_type_id nvarchar(8),
    icc_id nvarchar(19) DEFAULT NULL,
    ipv4_address nvarchar(15),
    sunrise datetime DEFAULT NULL,
    sunset datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    latitude_user double precision,
    longitude_user double precision,
    latitude_m2m double precision,
    longitude_m2m double precision,
    geodetic_use_status smallint DEFAULT 1 NOT NULL,
    node_timezone nvarchar(50) DEFAULT NULL
);

--
-- Name: sn_parameter; Type: TABLE;
--

CREATE TABLE sn_parameter (
    id int identity(1, 1) primary key,
    sn_id nvarchar(12) DEFAULT NULL,
    sn_config_id int,
    contract_id int,
    use_start_datetime datetime DEFAULT NULL,
    use_end_datetime datetime DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: sn_status; Type: TABLE;
--

CREATE TABLE sn_status (
    id int identity(1, 1) primary key,
    sn_config_id int,
    status_date datetime NOT NULL,
    sn_id nvarchar(12) DEFAULT NULL,
    measure_id int,
    battery_level int,
    battery_status int,
    wifi_level int,
    total_point int,
    total_point_max int,
    measure_point int,
    measure_point_max int,
    threshold_point int,
    threshold_point_max int,
    ek_field_view_point int,
    ek_field_view_point_max int,
    sensor_status_temperature int NOT NULL,
    sensor_status_solar int NOT NULL,
    sensor_status_moisture_ec int NOT NULL,
    sensor_status_thermistor_a int NOT NULL,
    sensor_status_thermistor_b int NOT NULL,
    sensor_status_analog int NOT NULL,
    sensor_status_serial int NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: stage_knowledge; Type: TABLE;
--

CREATE TABLE stage_knowledge (
    id int identity(1, 1) primary key,
    recipe_stage_id int NOT NULL,
    start_recipe_stage_id int NOT NULL,
    knowledge_name nvarchar(255) NOT NULL,
    knowledge_type nvarchar(8) NOT NULL,
    notification_type smallint NOT NULL,
    basis_value decimal(5,1) DEFAULT 0,
    target_value decimal(5,1) DEFAULT 0 NOT NULL,
    message text,
    sort_no int,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    stage_work_id int,
    up_down_type smallint
);

--
-- Name: stage_sensor_measure_item; Type: TABLE;
--

CREATE TABLE stage_sensor_measure_item (
    id int identity(1, 1) primary key,
    recipe_stage_id int,
    sensor_measure_item_id int,
    item_name nvarchar(255) NOT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: stage_sensor_position; Type: TABLE;
--

CREATE TABLE stage_sensor_position (
    id int identity(1, 1) primary key,
    recipe_stage_id int NOT NULL,
    sensor_type smallint NOT NULL,
    title nvarchar(255) DEFAULT NULL,
    url text,
    description text,
    image_path nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: stage_sn_threshold; Type: TABLE; Schema: public; Owner: ews; Tablespace: 
--

CREATE TABLE stage_sn_threshold (
    id int identity(1, 1) primary key,
    recipe_stage_id int NOT NULL,
    sensor_measure_item_id int NOT NULL,
    danger_bottom decimal(5,1) DEFAULT NULL,
    danger_upper decimal(15,1) DEFAULT NULL,
    warning_bottom decimal(5,1) DEFAULT NULL,
    warning_upper decimal(5,1) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    stage_sensor_measure_item_id int NOT NULL
);

--
-- Name: stage_widget; Type: TABLE; Schema: public; Owner: ews; Tablespace: 
--

CREATE TABLE stage_widget (
    id int identity(1, 1) primary key,
    recipe_stage_id int NOT NULL,
    widget_id int NOT NULL,
    stage_knowledge_id int,
    display_flag bit DEFAULT 0 NOT NULL,
    sort_no int,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: stage_work; Type: TABLE; Schema: public; Owner: ews; Tablespace: 
--

CREATE TABLE stage_work (
    id int identity(1, 1) primary key,
    recipe_stage_id int NOT NULL,
    title nvarchar(255) NOT NULL,
    url text,
    content text NOT NULL,
    image_path nvarchar(255) DEFAULT NULL,
    sort_no int,
    created_at datetime DEFAULT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: supplyment_expression; Type: TABLE;
--

CREATE TABLE supplyment_expression (
    id int identity(1, 1) primary key,
    sn_parameter_id int,
    sensor_measure_item_id int,
    expression nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: threshold; Type: TABLE;
--

CREATE TABLE threshold (
    id int identity(1, 1) primary key,
    client_system_info_id int,
    template_type smallint NOT NULL,
    threshold_name nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: threshold_detail; Type: TABLE;
--

CREATE TABLE threshold_detail (
    id int identity(1, 1) primary key,
    threshold_id int,
    sensor_measure_item_id int,
    danger_bottom decimal(5,1) DEFAULT NULL,
    danger_upper decimal(5,1) DEFAULT NULL,
    warning_bottom decimal(5,1) DEFAULT NULL,
    warning_upper decimal(5,1) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- Name: timeline; Type: TABLE;
--

CREATE TABLE timeline (
    id int identity(1, 1) primary key,
    timeline_datetime datetime NOT NULL,
    client_id int,
    gw_config_id int,
    gw_id nvarchar(12) DEFAULT NULL,
    sn_config_id int,
    sn_id nvarchar(12) DEFAULT NULL,
    node_name nvarchar(255) DEFAULT NULL,
    ekfield_id int,
    recipe_id int,
    recipe_stage_id int,
    timeline_status int,
    timeline_type int,
    sensor_measure_item_id int,
    stage_knowledge_id int,
    knowledge_name nvarchar(255) DEFAULT NULL,
    knowledge_type nvarchar(8),
    knowledge_notification_type smallint,
    threshold_value double precision,
    watch_type int,
    value double precision,
    diary_id int,
    title nvarchar(255) DEFAULT NULL,
    description text,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL,
    measure_id int,
    has_changed int,
    ekfield_name nvarchar(255) DEFAULT NULL
);

--
-- Name: widget; Type: TABLE; Schema: public; Owner: ews; Tablespace: 
--

CREATE TABLE widget (
    id int identity(1, 1) primary key,
    widget_name nvarchar(255) NOT NULL,
    is_recipe_widget bit NOT NULL,
    is_knowledge_widget bit NOT NULL,
    sort_no int NOT NULL,
    image_path nvarchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    deleted_at datetime DEFAULT NULL
);

--
-- MSSQL database dump complete
--